﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyTakeaway.Models
{
    public class CategoryViewModel
    {
        public IList<CategoryModel> CategoryDataList { get; set; }
    }
}
