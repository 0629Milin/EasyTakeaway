﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyTakeaway.Models
{
    public static class GeneralHelper
    {
        /// <summary>
        /// To Bind the List of Categories
        /// </summary>
        /// <returns></returns>
        public static IList<CategoryModel> GetCategories()
        {
            IList<CategoryModel> lstCategoryModel;

            try
            {
                lstCategoryModel = new[]
                {
                    new CategoryModel { ID = 1, Title="Live Food", ImageName="livefood.png"},
                    new CategoryModel { ID = 2, Title="Ready To Take", ImageName="preparedfood.jpg"}
                }.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCategoryModel;
        }
    }
}
