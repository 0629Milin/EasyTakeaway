﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyTakeaway.Models
{
    public class MenuViewModel
    {
        public string Title { get; set; }
        public IList<MenuModel> MenuList { get; set; }
    }
}
