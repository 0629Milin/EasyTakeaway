﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyTakeaway.Models
{
    public static class GeneralHelper
    {
        /// <summary>
        /// To Bind the List of Categories
        /// </summary>
        /// <returns></returns>
        public static IList<CategoryModel> GetCategories()
        {
            IList<CategoryModel> lstCategoryModel;

            try
            {
                lstCategoryModel = new[]
                {
                    new CategoryModel { Id = 1, CategpryCode = "LF", Title="Live Food", ImageName="livefood.png"},
                    new CategoryModel { Id = 2, CategpryCode = "PF" , Title="Ready To Take", ImageName="preparedfood.jpg"}
                }.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCategoryModel;
        }

        /// <summary>
        /// To Bind the List of Menu
        /// </summary>
        /// <returns></returns>
        public static IList<MenuModel> GetMenuList(string strCategoryCode)
        {
            IList<MenuModel> lstMenuModel = null;

            try
            {
                switch (strCategoryCode.ToUpperInvariant())
                {
                    case "LF":
                        lstMenuModel = new[]
                        {
                                new MenuModel { Id = 1, Name="Fafda", UOM="Kg", QTY=1, Price=400, ImageName="livefood.png"}
                        }.ToList();
                        break;
                    case "PF":
                        lstMenuModel = new[]
                        {
                                new MenuModel { Id = 1, Name="Papdi", UOM="Kg", QTY=1, Price=300, ImageName="preparedfood.jpg"}
                        }.ToList();
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMenuModel;
        }
    }
}
