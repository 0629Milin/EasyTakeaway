﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EasyTakeaway.Models;
using Microsoft.AspNetCore.Mvc;

namespace EasyTakeaway.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            // Bind list of main food categories
            CategoryViewModel objCategoryViewModel = new CategoryViewModel();
            objCategoryViewModel.CategoryDataList = (List<CategoryModel>)GeneralHelper.GetCategories();

            return View(objCategoryViewModel);
        }


        public IActionResult GetMenuList(string strCategoryCode)
        {
            // Bind category wise menulist
            MenuViewModel objMenuViewModel = new MenuViewModel();
            objMenuViewModel.MenuList = (List<MenuModel>)GeneralHelper.GetMenuList(strCategoryCode);


            return View();
        }
    }
}