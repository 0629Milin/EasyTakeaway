﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UploadXMLData.AppCode
{
    public static class General
    {
        /// <summary>
        /// To write a log. 
        /// </summary>
        /// <param name="rootDirectory"></param>
        /// <param name="strMessage"></param>
        /// <param name="strName"></param>
        /// <param name="IsTitle"></param>
        /// <param name="blankLine"></param>
        public static void WriteLog(string rootDirectory, string strMessage, string strName, bool IsTitle, bool blankLine)
        {
            try
            {
                string strPath = Path.Combine(rootDirectory, "Log");
                if (Directory.Exists(strPath) == false)
                {
                    Directory.CreateDirectory(strPath);
                }
                string strFileName = strPath + "\\" + strName + "_WriteXML_" + DateTime.Now.ToString("yyyyMMdd") + ".log";
                if (File.Exists(strFileName) == false)
                {
                    File.Create(strFileName).Close();
                }
                StreamWriter file = File.AppendText(strFileName);

                if (IsTitle)
                {
                    file.WriteLine();
                    file.WriteLine("----------------------------------------------------------------------------------------------------------");
                }

                if (blankLine)
                {
                    file.WriteLine();
                }

                file.WriteLine(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + "\t" + strMessage);

                file.Flush();
                file.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string SetupDirectories(string rootDirectory)
        {
            try
            {
                string rootDestinationDirectory = Path.Combine(rootDirectory, "Transaction");
                if (!Directory.Exists(rootDestinationDirectory))
                {
                    Directory.CreateDirectory(rootDestinationDirectory);
                }
                return rootDestinationDirectory;
            }
            catch (Exception ex)
            {
                WriteLog(rootDirectory, "Error in setupDirectories : " + Convert.ToString(ex.Message), "Error", false, true);
            }
            return null;
        }
    }
}
