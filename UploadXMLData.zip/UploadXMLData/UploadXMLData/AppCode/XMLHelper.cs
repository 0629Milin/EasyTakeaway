﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UploadXMLData.AppCode
{
    public static class XMLHelper
    {
        public static void DumpXMLData(string sourcePath, string destinationPath, string rootDirectory)
        {
            try
            {
                string[] filePaths = Directory.GetFiles(sourcePath);
                foreach (var filename in filePaths)
                {
                    string file = filename.ToString();

                    string[] arrFilename = file.Split('.');
                    string extension = arrFilename[arrFilename.Length - 1];

                    if (extension.ToUpperInvariant() == "XML")
                    {
                        string strDestinationFilePath = Path.Combine(destinationPath, Path.GetFileName(file));
                        
                        if (!File.Exists(strDestinationFilePath))
                        {
                            File.Copy(file, strDestinationFilePath);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                General.WriteLog(rootDirectory, "Error on DumpXMLData, Error Message : " + ex.Message, "Error", false, true);
                throw ex;
            }   
        }
    }
}
