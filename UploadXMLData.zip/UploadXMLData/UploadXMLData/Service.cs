﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using UploadXMLData.AppCode;

namespace UploadXMLData
{
    public partial class Service : ServiceBase
    {
        string rootbaseDirectory = System.Reflection.Assembly.GetEntryAssembly().Location;
        string rootDirectory = string.Empty;
        string sourcePath = "M:\\Milin\\Projects\\XML_Dump\\Source";
        string destinationPath = "";

        public Service()
        {
            InitializeComponent();
            rootDirectory = System.IO.Path.GetDirectoryName(rootbaseDirectory);

            General.WriteLog(rootDirectory, "OnStart call start", "Info", true, false);

            destinationPath = General.SetupDirectories(rootDirectory);
            XMLHelper.DumpXMLData(sourcePath, destinationPath, rootDirectory);

            General.WriteLog(rootDirectory, "OnStart call Completed", "Info", true, false);

        }

        protected override void OnStart(string[] args)
        {
            General.WriteLog(rootDirectory,"OnStart call start","Info",true,false);

            destinationPath = General.SetupDirectories(rootDirectory);
            XMLHelper.DumpXMLData(sourcePath,destinationPath,rootDirectory);

            General.WriteLog(rootDirectory, "OnStart call Completed", "Info", true, false);
        }

        protected override void OnStop()
        {
            General.WriteLog(rootDirectory, "OnStop called", "Info", true, false);
        }
    }
}
