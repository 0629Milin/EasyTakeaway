﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyTakeaway.Models
{
    public static class General
    {
        /// <summary>
        /// The Food Categories
        /// </summary>
        public enum Categories{

            LiveFood,

            ReadyToTake
        }
    }
}
