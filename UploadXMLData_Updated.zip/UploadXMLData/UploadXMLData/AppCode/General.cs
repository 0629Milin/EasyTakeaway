﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UploadXMLData.AppCode
{
    public static class General
    {
        /// <summary>
        /// To write a log. 
        /// </summary>
        /// <param name="rootDirectory"></param>
        /// <param name="strMessage"></param>
        /// <param name="strName"></param>
        /// <param name="IsTitle"></param>
        /// <param name="blankLine"></param>
        public static void WriteLog(string rootDirectory, string strMessage, string strName, bool IsTitle, bool blankLine)
        {
            try
            {
                string strPath = Path.Combine(rootDirectory, "Log");
                if (Directory.Exists(strPath) == false)
                {
                    Directory.CreateDirectory(strPath);
                }
                string strFileName = strPath + "\\" + strName + "_WriteXML_" + DateTime.Now.ToString("yyyyMMdd") + ".log";
                if (File.Exists(strFileName) == false)
                {
                    File.Create(strFileName).Close();
                }
                StreamWriter file = File.AppendText(strFileName);

                if (IsTitle)
                {
                    file.WriteLine();
                    file.WriteLine("----------------------------------------------------------------------------------------------------------");
                }

                if (blankLine)
                {
                    file.WriteLine();
                }

                file.WriteLine(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + "\t" + strMessage);

                file.Flush();
                file.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string SetupDirectories(string rootDirectory)
        {
            try
            {
                string rootDestinationDirectory = Path.Combine(rootDirectory, "Transaction");
                if (!Directory.Exists(rootDestinationDirectory))
                {
                    Directory.CreateDirectory(rootDestinationDirectory);
                }
                return rootDestinationDirectory;
            }
            catch (Exception ex)
            {
                WriteLog(rootDirectory, "Error in setupDirectories : " + Convert.ToString(ex.Message), "Error", false, true);
            }
            return null;
        }

        #region XMLHelper

        public static void DumpXMLData(string rootDirectory)
        {
            try
            {
                string configFileFormat = ConfigurationManager.AppSettings["fileFormat"];
                string sourcePath = ConfigurationManager.AppSettings["sourcePath"];
                string destinationPath = GetDestinationPath(rootDirectory);
                
                 
                string[] filePaths = Directory.GetFiles(sourcePath);
                foreach (var file in filePaths)
                {
                    string filePath = Convert.ToString(file);
                    string extension = GetFileFormat(filePath);
                    

                    if (extension.ToUpperInvariant() == configFileFormat.ToUpperInvariant())
                    {
                        string strDestinationFilePath = Path.Combine(destinationPath, Path.GetFileName(file));

                        if (!File.Exists(strDestinationFilePath))
                        {
                            File.Copy(filePath, strDestinationFilePath);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                General.WriteLog(rootDirectory, "Error on DumpXMLData, Error Message : " + ex.Message, "Error", false, true);
                throw ex;
            }
        }

        private static string GetFileFormat(string filePath)
        {
            try
            {
                string[] arrFilename = filePath.Split('.');
                string extension = arrFilename[arrFilename.Length - 1];
                return extension;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static string GetDestinationPath(string rootDirectory)
        {
            try
            {
                string destinationPath = string.Empty;
                string strConfigDestination = ConfigurationManager.AppSettings["destinationPath"];
                
                if (string.IsNullOrEmpty(strConfigDestination))
                {
                    destinationPath = General.SetupDirectories(rootDirectory);
                }
                else
                {
                    destinationPath = strConfigDestination;
                }
                return destinationPath;
            }
            catch (Exception ex)
            {
                throw ex;
            }          
        }

        #endregion
    }
}
