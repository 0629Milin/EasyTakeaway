﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using UploadXMLData.AppCode;

namespace UploadXMLData
{
    public partial class Service1 : ServiceBase
    {
        readonly string rootbaseDirectory = System.Reflection.Assembly.GetEntryAssembly().Location;
        string rootDirectory = string.Empty;
       

        public Service1()
        {
            InitializeComponent(); 
           // rootDirectory = System.IO.Path.GetDirectoryName(rootbaseDirectory);

            //General.WriteLog(rootDirectory, "OnStart call start", "Info", true, false);
            //General.DumpXMLData(rootDirectory);
            //General.WriteLog(rootDirectory, "OnStart call Completed", "Info", true, false);
        }

        protected override void OnStart(string[] args)
        {
            rootDirectory = System.IO.Path.GetDirectoryName(rootbaseDirectory);
            General.WriteLog(rootDirectory,"OnStart call start","Info",true,false);
            General.DumpXMLData(rootDirectory);
            General.WriteLog(rootDirectory, "OnStart call Completed", "Info", true, false);
        }

        protected override void OnStop()
        {
            General.WriteLog(rootDirectory, "OnStop called", "Info", true, false);
        }
    }
}
